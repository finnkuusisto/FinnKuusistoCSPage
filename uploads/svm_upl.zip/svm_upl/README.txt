Instructions
------------
The included svm_perf_upl.patch is a patch file that includes our modifications to svm_perf since the svm_perf license disallows distribution of the entirety of the code.  The patch command can be used to apply the necessary changes:
1. Download the svm_perf source (v. 3.00) from http://www.cs.cornell.edu/people/tj/svm_light/svm_perf.html
2. Untar the contents into a directory named svm_perf
3. Place the patch file in the parent directory of the svm_perf directory
4. cd to the parent directory of the svm_perf directory
5. Run 'patch -u -p1 -i svm_perf_upl.patch'

That should modify three files, and you should then be able to compile and run it.

The usage list contains everything you need, but you'll care most about the -l and --z options.  The -l option allows you to choose the loss function, and you should use the Uplift loss function (13).  The --z option tells it where in the training file the control subgroup of examples starts.  That is, your training file should consist of all the target group examples followed by the control group examples. For example, if you have a training set consisting of 100 target group examples and 100 control group examples, the command you run would look something like:
svm_perf_learn -c 1.0 -l 13 --z 100 -w 3 train.data model

The -c option is simply for setting the cost as usual and the '-w 3' tells it to use the cutting-plane solver, which you'll also need to use.  This will dump the model to a file named model, which you can use with svm_perf_classify to run on your test set. 

Academic Attribution
--------------------
If this work is used in publication, please cite:
@inproceedings{kuusisto.ecml14,
    author    = "F. Kuusisto and V. Santos Costa and H. Nassif and E. Burnside and D. Page and J. Shavlik",
    title        = "Support Vector Machines for Differential Prediction",
    booktitle = "Proceedings of the European Conference on Machine Learning (ECML)",
    year       = "2014",
}